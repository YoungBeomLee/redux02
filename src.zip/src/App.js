import Products from "./components/products";
import './App.css';

function App() {
  return (
    <div className="App">
      <Products></Products>
    </div>
  );
}

export default App;
